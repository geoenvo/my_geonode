"""All is spam, spam checker backend for Zinnia"""


def backend(comment, content_object, request):
    """
    Backend for setting all comments to spam.
    """
    return True
