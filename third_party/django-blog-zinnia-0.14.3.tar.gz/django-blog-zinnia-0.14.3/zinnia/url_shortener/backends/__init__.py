"""URL shortener backends for Zinnia"""
