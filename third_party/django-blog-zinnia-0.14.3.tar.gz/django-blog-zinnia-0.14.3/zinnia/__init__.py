"""Zinnia"""
__version__ = '0.14.3'
__license__ = 'BSD License'

__author__ = 'Fantomas42'
__email__ = 'fantomas42@gmail.com'

__url__ = 'https://github.com/Fantomas42/django-blog-zinnia'
