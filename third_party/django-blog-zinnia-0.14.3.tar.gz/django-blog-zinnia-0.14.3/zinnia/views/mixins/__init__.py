"""Mixins for Zinnia views"""
