"""
Implementation components at the project level
needed for testing Zinnia.
"""
