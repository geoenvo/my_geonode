backends Package
================

:mod:`backends` Package
-----------------------

.. automodule:: zinnia.url_shortener.backends
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`default` Module
---------------------

.. automodule:: zinnia.url_shortener.backends.default
    :members:
    :undoc-members:
    :show-inheritance:

