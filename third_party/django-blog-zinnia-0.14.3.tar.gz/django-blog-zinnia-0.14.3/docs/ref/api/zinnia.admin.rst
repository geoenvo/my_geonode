admin Package
=============

:mod:`admin` Package
--------------------

.. automodule:: zinnia.admin
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`category` Module
----------------------

.. automodule:: zinnia.admin.category
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`entry` Module
-------------------

.. automodule:: zinnia.admin.entry
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`fields` Module
---------------------

.. automodule:: zinnia.admin.fields
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`filters` Module
---------------------

.. automodule:: zinnia.admin.filters
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`forms` Module
-------------------

.. automodule:: zinnia.admin.forms
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`widgets` Module
---------------------

.. automodule:: zinnia.admin.widgets
    :members:
    :undoc-members:
    :show-inheritance:

