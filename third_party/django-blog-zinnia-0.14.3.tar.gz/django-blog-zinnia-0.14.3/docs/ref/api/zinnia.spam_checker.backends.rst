backends Package
================

:mod:`backends` Package
-----------------------

.. automodule:: zinnia.spam_checker.backends
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`all_is_spam` Module
-------------------------

.. automodule:: zinnia.spam_checker.backends.all_is_spam
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`long_enough` Module
-------------------------

.. automodule:: zinnia.spam_checker.backends.long_enough
    :members:
    :undoc-members:
    :show-inheritance:
