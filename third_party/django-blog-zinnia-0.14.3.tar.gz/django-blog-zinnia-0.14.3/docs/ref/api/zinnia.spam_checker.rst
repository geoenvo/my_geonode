spam_checker Package
====================

:mod:`spam_checker` Package
---------------------------

.. automodule:: zinnia.spam_checker
    :members:
    :undoc-members:
    :show-inheritance:

Subpackages
-----------

.. toctree::

    zinnia.spam_checker.backends

