======
Thanks
======

Zinnia cannot be a great application without great contributors who make
this application greatest each day.

.. include:: ../../AUTHORS


And also a special thank to `GitHub.com`_, `Transifex.net`_, `Travis-CI`_,
`Coveralls`_, and `ReadTheDocs.org`_ for their services of great quality.


.. _`GitHub.com`: https://www.github.com/
.. _`Transifex.net`: https://www.transifex.net/
.. _`Travis-CI`: https://travis-ci.org/
.. _`Coveralls`: https://coveralls.io/
.. _`ReadTheDocs.org`: http://readthedocs.org/
