"""Extensions module for the documation of Zinnia"""
